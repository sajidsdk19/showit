<?php
/*
Plugin Name: Show Only Posts in Search (Exclude Tags)
Description: A plugin to show only posts in WordPress search results, excluding pages and posts with specific tags.
Version: 1.3
Author: sajid   
License: GPL2
*/

// Prevent direct access to this file
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Show only posts in search results by modifying the main query
 * This excludes pages, categories, and any other post types
 * Also excludes posts with specific tags and specific categories
 *
 * @param WP_Query $query The WordPress query object
 * @return void
 */
function epfs_show_only_posts_in_search($query) {
    // Check if it's a search query, main query, and not in admin
    if ($query->is_search() && $query->is_main_query() && !is_admin()) {
        // Only show posts (excludes pages, categories, custom post types, etc.)
        $query->set('post_type', 'post');
        
        // Only show published posts (excludes drafts, private posts, etc.)
        $query->set('post_status', 'publish');
        
        // Exclude posts with specific tag IDs
        $excluded_tag_ids = array(1394, 1396, 1703, 1398);
        $query->set('tag__not_in', $excluded_tag_ids);
        
        // Exclude posts from specific categories (homeschool and lifestyle)
        // Get category IDs by slug
        $homeschool_cat = get_category_by_slug('homeschool');
        $lifestyle_cat = get_category_by_slug('lifestyle');
        
        $excluded_category_ids = array();
        if ($homeschool_cat) {
            $excluded_category_ids[] = $homeschool_cat->term_id;
        }
        if ($lifestyle_cat) {
            $excluded_category_ids[] = $lifestyle_cat->term_id;
        }
        
        // If you know the exact category IDs, you can use them directly instead:
        // $excluded_category_ids = array(123, 456); // Replace with actual IDs
        
        if (!empty($excluded_category_ids)) {
            $query->set('category__not_in', $excluded_category_ids);
        }
        
        // Ensure we're not searching in taxonomy terms
        $query->set('suppress_filters', false);
    }
}

/**
 * Completely block category and tag archive pages from search results
 * This prevents WordPress from showing category/tag pages in search
 */
function epfs_block_taxonomy_pages_from_search() {
    if (is_search() && !is_admin()) {
        // If current page is a category or tag archive, redirect or return 404
        if (is_category() || is_tag()) {
            global $wp_query;
            $wp_query->set_404();
            status_header(404);
            return;
        }
    }
}
add_action('template_redirect', 'epfs_block_taxonomy_pages_from_search');

/**
 * Remove specific category pages from search results completely
 * This targets the exact categories: homeschool and lifestyle
 */
function epfs_remove_specific_categories_from_search($posts, $query) {
    if (!is_admin() && $query->is_search() && $query->is_main_query()) {
        // Remove any results that are category archive pages
        $filtered_posts = array();
        foreach ($posts as $post) {
            // Only keep actual posts, not category pages
            if ($post->post_type === 'post') {
                $filtered_posts[] = $post;
            }
        }
        return $filtered_posts;
    }
    return $posts;
}
add_filter('the_posts', 'epfs_remove_specific_categories_from_search', 10, 2);
add_action('pre_get_posts', 'epfs_show_only_posts_in_search');

/**
 * Optional: Remove categories and tags from search suggestions/autocomplete
 * and prevent them from being included in search results
 */
function epfs_remove_taxonomy_from_search_completely() {
    // Remove taxonomy terms from search
    add_filter('get_terms', function($terms, $taxonomies, $args) {
        if (is_search() && !is_admin()) {
            return array();
        }
        return $terms;
    }, 10, 3);
    
    // Prevent category/tag archive pages from being searchable
    add_action('parse_query', function($query) {
        if ($query->is_search() && !is_admin()) {
            // Ensure only post post_type is searched
            $query->set('post_type', 'post');
            // Remove any taxonomy queries
            $query->set('tax_query', array());
        }
    });
}
add_action('init', 'epfs_remove_taxonomy_from_search_completely');
?>